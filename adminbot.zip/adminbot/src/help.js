const help = (prefix) => {
	return `> *Sticker Commands* <
𝐅𝐈𝐓𝐔𝐑 𝐓𝐎𝐓

𝗞𝗘𝗧 : 𝗦𝗖 𝗠𝗔𝗦𝗜 𝗗𝗔𝗟𝗔𝗠 𝗣𝗘𝗥𝗞𝗘𝗠𝗕𝗔𝗡𝗚𝗔𝗡

╭┈───────(About
╰─➤ *${prefix}owner*
╰─➤ *${prefix}donate*
╰─➤ *${prefix}Info*

╭┈───────(Marker
╰─➤ *${prefix}sticker*
╰─➤ *${prefix}sticker nobg*
╰─➤ *${prefix}toimg*
╰─➤ *${prefix}tsticker*
╰─➤ *${prefix}nulis*
 
╭┈───────Meme
╰─➤ *${prefix}meme*
╰─➤ *${prefix}memeindo*

╭┈───────(Media
╰─➤ *${prefix}tts*
╰─➤ *${prefix}loli*
╰─➤ *${prefix}nsfwloli*
╰─➤ *${prefix}url2img*
╰─➤ *${prefix}ocr*
╰─➤ *${prefix}simi*
╰─➤ *${prefix}tiktok*

╭┈───────(Group
╰─➤ *${prefix}linkgroup*
╰─➤ *${prefix}tagall*
╰─➤ *${prefix}simih [1-0]*
╰─➤ *${prefix}nsfw [1-0]*
╰─➤ *${prefix}group [buka-tutup]*
╰─➤ *${prefix}welcome [1-0]*
╰─➤ *${prefix}promote [tag]*
╰─➤ *${prefix}demote [tag]*
╰─➤ *${prefix}clone [tag]*
╰─➤ *${prefix}setpp*
╰─➤ *${prefix}kick [tag]*
╰─➤ *${prefix}Add [628xxx]*

╭┈───────(Download
╰─➤ *${prefix}yt [link]*

╭┈───────(Others
╰─➤ *${prefix}ytsearch*
╰─➤ *${prefix}listadmin*
╰─➤ *${prefix}blocklist*
╰─➤ *${prefix}fitnah*
╰─➤ *${prefix}tiktokstalk*
╰─➤ *${prefix}wait*

╭┈───────(Owner
╰─➤ *${prefix}bc*
╰─➤ *${prefix}leave*
╰─➤ *${prefix}clearall*
╰─➤ *${prefix}setprefix*
╰─➤ *${prefix}block*
╰─➤ *${prefix}unblock*`
}

exports.help = help
